(function($) {
    "use strict"


    // MAterial Date picker
    $('#mdate').bootstrapMaterialDatePicker({
        weekStart: 0,
        time: false
    });


















})(jQuery);